async function register() {
    const registrationNumber = document.getElementById('registration-number').value;
    const name = document.getElementById('name').value;
    // Add more fields as needed for registration

    try {
        const response = await fetch('/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ registrationNumber, name })
        });

        if (response.ok) {
            const userData = await response.json();
            displayProfile(userData);
        } else {
            const errorMessage = await response.text();
            alert(`Registration failed: ${errorMessage}`);
        }
    } catch (error) {
        console.error('Error during registration:', error);
        alert('An error occurred during registration. Please try again later.');
    }
}

function displayProfile(userData) {
    const profileDisplay = document.getElementById('profile-display');
    const profileInfo = document.getElementById('profile-info');

    profileInfo.innerHTML = `
        <h2>Welcome, ${userData.name}!</h2>
        <p>Registration Number: ${userData.registrationNumber}</p>
        <!-- Add more profile information as needed -->
    `;

    profileDisplay.style.display = 'block';
}


function redirectToLogin() {
    // Redirect to login page
    window.location.href = "login.html";
}
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
}
function toggleMenu() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('active');
    
    // Apply specific styling for Windows when the menu is active
    if (isWindows() && menu.classList.contains('active')) {
        menu.classList.add('windows');
    } else {
        menu.classList.remove('windows');
    }
}

// Function to detect Windows OS
function isWindows() {
    return navigator.platform.toUpperCase().indexOf('WIN') >= 0;
}
[
    { slotNumber: 1, availability: true, vehicle: null },
    { slotNumber: 2, availability: true, vehicle: { plateNumber: "ABC123", owner: "John Doe" } },
    // Add more parking slots as needed
]


function openMap() {
    // Open Google Maps or perform any other action related to map exploration
    alert("Opening Google Maps...");
}

function redirectToLogin() {
    // Redirect to login page
    window.location.href = "login.html";
}